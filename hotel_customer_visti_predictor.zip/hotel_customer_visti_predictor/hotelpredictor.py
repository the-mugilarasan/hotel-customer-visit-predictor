import streamlit as st
import pandas as pd
from datetime import datetime
import calendar
import joblib
import os

# Page configuration
st.set_page_config(
    page_title="Hotel Customer Visit Predictor",
    page_icon="🏨",
    layout="wide"
)

# Custom CSS for styling
st.markdown("""
<style>
    .header-container {
        background: linear-gradient(135deg, #1E293B 0%, #0F172A 100%);
        padding: 1.8rem 2rem;
        border-radius: 12px;
        margin-bottom: 1.8rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }
    .main-header {
        font-size: 2.3rem;
        font-weight: 700;
        color: #FFFFFF !important;
        margin-bottom: 0.3rem;
    }
    .sub-header {
        font-size: 1.1rem;
        color: #FFFFFF !important;
        opacity: 0.95;
        margin-bottom: 0;
    }
</style>
""", unsafe_allow_html=True)

# Path configuration for model
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_FILENAME = "catboost_model.pkl"
MODEL_PATH = os.path.join(BASE_DIR, MODEL_FILENAME)

# Fallback path check
if not os.path.exists(MODEL_PATH):
    parent_dir_path = os.path.join(os.path.dirname(BASE_DIR), MODEL_FILENAME)
    if os.path.exists(parent_dir_path):
        MODEL_PATH = parent_dir_path

@st.cache_resource
def load_model(path):
    if not os.path.exists(path):
        return None
    try:
        return joblib.load(path)
    except Exception as e:
        st.error(f"Error loading model from {path}: {e}")
        return None

model = load_model(MODEL_PATH)

st.markdown("""
<div class="header-container">
    <div class="main-header">🏨 Hotel Customer Visit Predictor</div>
    <div class="sub-header">Predict future return visit dates for hotel guests using machine learning patterns.</div>
</div>
""", unsafe_allow_html=True)

if model is None:
    st.error(f"⚠️ Model file `{MODEL_FILENAME}` could not be found or loaded. Searched path: `{MODEL_PATH}`")
    st.stop()

# Sidebar options
st.sidebar.header("📁 Data Source")
uploaded_file = st.sidebar.file_uploader("Upload Customer CSV File", type=["csv"])

default_csv_path = os.path.join(BASE_DIR, "hotel_customer_visits_1000.csv")
use_default = False

if uploaded_file is None and os.path.exists(default_csv_path):
    st.sidebar.info("Using default sample dataset (`hotel_customer_visits_1000.csv`). Upload your own CSV above to analyze custom data.")
    use_default = True

df = None
if uploaded_file is not None:
    df = pd.read_csv(uploaded_file)
elif use_default:
    df = pd.read_csv(default_csv_path)

if df is not None:
    required_cols = ['lastvisitdate', 'previousvisitdate', 'totalvisityear', 'visits_in_month', 'customername']
    missing_cols = [col for col in required_cols if col not in df.columns]

    if missing_cols:
        st.error(f"The uploaded file is missing required columns: {', '.join(missing_cols)}")
        st.stop()

    # Preprocessing
    df['lastvisitdate_parsed'] = pd.to_datetime(df['lastvisitdate'], format="%d-%m-%Y", errors='coerce')
    df['previousvisitdate_parsed'] = pd.to_datetime(df['previousvisitdate'], format="%d-%m-%Y", errors='coerce')

    df['lastvisitmonth'] = df['lastvisitdate_parsed'].dt.month
    df['lastvisitweekday'] = df['lastvisitdate_parsed'].dt.weekday
    df['previousvisitmonth'] = df['previousvisitdate_parsed'].dt.month
    df['previousvisitweekday'] = df['previousvisitdate_parsed'].dt.weekday

    features = [
        'totalvisityear', 'lastvisitmonth', 'lastvisitweekday',
        'previousvisitmonth', 'previousvisitweekday', 'visits_in_month'
    ]

    X = df[features]
    df['predicted_gap'] = model.predict(X).round().astype(int)
    df['predicted_next_visitdate'] = df['lastvisitdate_parsed'] + pd.to_timedelta(df['predicted_gap'], unit='D')
    df['predicted_next_visitdate'] = pd.to_datetime(df['predicted_next_visitdate'])

    # Format dates for display
    df['Last Visit'] = df['lastvisitdate_parsed'].dt.strftime('%Y-%m-%d')
    df['Predicted Next Visit'] = df['predicted_next_visitdate'].dt.strftime('%Y-%m-%d')

    # Summary Metrics
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Customers Analyzed", f"{len(df):,}")
    with col2:
        st.metric("Avg Predicted Gap", f"{df['predicted_gap'].mean():.1f} days")
    with col3:
        st.metric("Min Return Gap", f"{df['predicted_gap'].min()} days")
    with col4:
        st.metric("Max Return Gap", f"{df['predicted_gap'].max()} days")

    st.markdown("---")

    st.subheader("📊 Customer Predictions Overview")
    preview_df = df[['customername', 'totalvisityear', 'visits_in_month', 'Last Visit', 'Predicted Next Visit', 'predicted_gap']].rename(
        columns={
            'customername': 'Customer Name',
            'totalvisityear': 'Visits / Year',
            'visits_in_month': 'Visits in Month',
            'predicted_gap': 'Predicted Gap (Days)'
        }
    )
    st.dataframe(preview_df.head(10), use_container_width=True)

    # Download Button
    csv_data = df.to_csv(index=False).encode('utf-8')
    st.download_button(
        label="📥 Download Full Predictions CSV",
        data=csv_data,
        file_name="hotel_predictions.csv",
        mime="text/csv",
    )

    st.markdown("---")

    st.subheader("📅 Monthly Prediction Filter & Calendar View")
    available_years = sorted(df['predicted_next_visitdate'].dt.year.dropna().unique().astype(int).tolist())
    default_year = available_years[0] if available_years else datetime.now().year

    # Determine default month with most visits
    monthly_counts = df['predicted_next_visitdate'].dt.month.value_counts()
    default_month = int(monthly_counts.idxmax()) if not monthly_counts.empty else 1

    col_m, col_y = st.columns(2)
    with col_m:
        selected_month = st.selectbox(
            "Select Month",
            list(range(1, 13)),
            index=default_month - 1,
            format_func=lambda x: calendar.month_name[x]
        )
    with col_y:
        selected_year = st.number_input(
            "Select Year",
            min_value=2020,
            max_value=2035,
            value=default_year,
            step=1
        )

    filtered = df[
        (df['predicted_next_visitdate'].dt.month == selected_month) &
        (df['predicted_next_visitdate'].dt.year == selected_year)
    ]

    st.success(f"📌 **{len(filtered)} customer(s)** expected to visit in **{calendar.month_name[selected_month]} {selected_year}**.")

    if not filtered.empty:
        filtered_view = filtered[['customername', 'Last Visit', 'Predicted Next Visit', 'predicted_gap']].rename(
            columns={
                'customername': 'Customer Name',
                'predicted_gap': 'Return Gap (Days)'
            }
        )
        st.dataframe(filtered_view, use_container_width=True)
    else:
        st.info("No customer visits predicted for this selected month and year.")

    st.markdown("#### 📆 Calendar View: Daily Visit Count")
    daily_counts = filtered['predicted_next_visitdate'].dt.day.value_counts().sort_index()
    total_days = calendar.monthrange(selected_year, selected_month)[1]
    calendar_data = {day: daily_counts.get(day, 0) for day in range(1, total_days + 1)}

    week_layout = []
    week = []
    first_weekday = calendar.monthrange(selected_year, selected_month)[0]  # 0 = Monday

    for _ in range(first_weekday):
        week.append("")

    for day in range(1, total_days + 1):
        count = calendar_data[day]
        val_str = f"Day {day}: {count} visits" if count > 0 else f"Day {day}"
        week.append(val_str)
        if len(week) == 7:
            week_layout.append(week)
            week = []

    if week:
        while len(week) < 7:
            week.append("")
        week_layout.append(week)

    calendar_df = pd.DataFrame(week_layout, columns=["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"])
    st.dataframe(calendar_df, use_container_width=True)

else:
    st.info("Please upload a Customer CSV file to begin analysis.")
