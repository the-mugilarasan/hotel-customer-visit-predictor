# 🏨 Hotel Customer Visit Predictor

An intelligent machine learning application built with **Streamlit** and **CatBoost** to predict hotel customer return visits and analyze customer booking patterns.

## 🚀 Features

- **Accurate Next-Visit Prediction**: Predicts return dates and visit gaps for customers based on historical patterns.
- **Interactive Streamlit Dashboard**: Clean, modern web UI for exploring customer visit predictions.
- **Monthly Visit Aggregation**: Summary of expected visitors for any selected month and year.
- **Interactive Calendar View**: Day-by-day expected customer visit distribution.
- **CSV Data Upload**: Supports uploading customer visit history datasets for batch predictions.

---

## 🛠️ Tech Stack & Requirements

- **Python 3.10+**
- **Streamlit**
- **CatBoost Regressor**
- **Pandas & NumPy**
- **Scikit-Learn**
- **Joblib**

All dependencies are listed in `requirements.txt`.

---

## 📦 Installation & Setup

1. **Clone the repository**:
   ```bash
   git clone https://github.com/harinics/hotel-customer-visit-predictor.git
   cd hotel-customer-visit-predictor
   ```

2. **Create and activate a virtual environment** (optional but recommended):
   ```bash
   python -m venv venv
   # Windows:
   .\venv\Scripts\activate
   # macOS / Linux:
   source venv/bin/activate
   ```

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Launch the application**:
   ```bash
   streamlit run hotelpredictor.py
   ```

---

## 📁 Repository Structure

```
├── .devcontainer/                             # VS Code Dev Container config
├── .gitignore                                 # Ignored files (venv, cache, etc.)
├── catboost_model.pkl                         # Trained CatBoost model file
├── hotel.ipynb                                # Jupyter notebook for model training & EDA
├── hotel_customer_visits_1000.csv             # Sample dataset of 1,000 customer visits
├── hotel_customer_visits_with_predictions.csv # Dataset augmented with prediction results
├── hotelpredictor.py                          # Main Streamlit web application
├── requirements.txt                           # Python project requirements
└── README.md                                  # Project documentation
```

---

## 📊 Model Information

- **Algorithm**: `CatBoostRegressor`
- **Target Variable**: `visit_gap` (number of days until next visit)
- **Features**: Total visits in year, last visit month/weekday, previous visit month/weekday, visits in month.
